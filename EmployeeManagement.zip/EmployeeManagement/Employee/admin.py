from django.contrib import admin
from .models import ModelDept,ModelEmpolyee
# Register your models here.

admin.site.register(ModelEmpolyee)
admin.site.register(ModelDept)

